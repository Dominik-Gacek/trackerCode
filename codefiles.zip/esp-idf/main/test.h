
void test_log();
